package com.example.hw.Post;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import com.example.hw.MainActivity;
import com.example.hw.R;

import org.jetbrains.annotations.NotNull;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class PostActivity extends AppCompatActivity implements View.OnClickListener {
    private static final String LOG_TAG = PostActivity.class.getSimpleName();
    private EditText postTitle, postMsg;
    private ImageButton postButton;
    private ImageView profile_pic_edit;
    private AppCompatActivity activity;
    private SharedPreferences pref;
    private Button btnCamera;
    private ImageView imageView;
    private String mCurrentPhotoPath;
    private File file = null;
    private String posttype;
    private String user_id;
    public static final int REQUEST_TAKE_PHOTO = 10;
    String img_src;
    int REQUEST_SELECT_PICTURE = 200;

    public PostActivity() {
        // require a empty public constructor
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(LOG_TAG, "Destroy");
        saveDraft();
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d(LOG_TAG, "Pause");
        saveDraft();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        //View v = inflater.inflate(R.layout.fragment_post, container, false);
        super.onCreate(savedInstanceState);

        setContentView(R.layout.fragment_post);
        Intent intent = getIntent();
        Bundle extras = intent.getExtras();
        posttype = extras.getString("type");
        user_id = extras.getString("user_id");
        Log.d("posttype", posttype);
        btnCamera = (Button) findViewById(R.id.postPhotoButton);
        profile_pic_edit = findViewById(R.id.postPic_edit);
        profile_pic_edit.setOnClickListener(this::chooseImage);
        if(posttype.equals("txtandimg"))
        {
            profile_pic_edit.setVisibility(View.VISIBLE);
            btnCamera.setText("拍照");
        }
        else if(posttype.equals("audio"))
        {
            profile_pic_edit.setVisibility(View.INVISIBLE);
            btnCamera.setText("录音");
        }
        else if(posttype.equals("video"))
        {
            profile_pic_edit.setVisibility(View.INVISIBLE);
            btnCamera.setText("录像");
        }
        //imageView = (ImageView) findViewById(R.id.imageView);

        postTitle = (EditText) findViewById(R.id.postTitle);
        postMsg = (EditText) findViewById(R.id.postMsg);
        postButton = (ImageButton) findViewById(R.id.postButton);
        postButton.setOnClickListener(this);
        btnCamera.setOnClickListener(this);
        pref = getSharedPreferences("Draft", 0);
        loadDraft();

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // 카메라 촬영을 하면 이미지뷰에 사진 삽입
        if (requestCode == REQUEST_TAKE_PHOTO) {
            File file = new File(mCurrentPhotoPath);
            this.file = file;
            Bitmap bitmap = null;
            try {
                bitmap = MediaStore.Images.Media
                        .getBitmap(getContentResolver(), Uri.fromFile(file));
            } catch (IOException e) {
                e.printStackTrace();
            }

            if (bitmap != null) {
                Log.d("bitmap",bitmap.toString());
                ExifInterface ei = null;
                try {
                    ei = new ExifInterface(mCurrentPhotoPath);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                int orientation = ei.getAttributeInt(ExifInterface.TAG_ORIENTATION,
                        ExifInterface.ORIENTATION_UNDEFINED);

//                            //사진해상도가 너무 높으면 비트맵으로 로딩
//                            BitmapFactory.Options options = new BitmapFactory.Options();
//                            options.inSampleSize = 8; //8분의 1크기로 비트맵 객체 생성
//                            Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath(), options);

                Bitmap rotatedBitmap = null;
                switch (orientation) {

                    case ExifInterface.ORIENTATION_ROTATE_90:
                        rotatedBitmap = rotateImage(bitmap, 90);
                        break;

                    case ExifInterface.ORIENTATION_ROTATE_180:
                        rotatedBitmap = rotateImage(bitmap, 180);
                        break;

                    case ExifInterface.ORIENTATION_ROTATE_270:
                        rotatedBitmap = rotateImage(bitmap, 270);
                        break;

                    case ExifInterface.ORIENTATION_NORMAL:
                    default:
                        rotatedBitmap = bitmap;
                }
                Log.d("rotated",rotatedBitmap.toString());
                //Rotate한 bitmap을 ImageView에 저장
                profile_pic_edit.setImageBitmap(rotatedBitmap);


            }
        }else if (requestCode == REQUEST_SELECT_PICTURE) {
            if(data.getData() == null){
                Log.d("","exit");
            }
            else{
                Uri selectedImageUri = data.getData();
                if (selectedImageUri != null) {
                    profile_pic_edit.setImageURI(selectedImageUri);

                    // Get actual file URI
                    String wholeID = DocumentsContract.getDocumentId(selectedImageUri);
                    String id = wholeID.split(":")[1];
                    String[] column = {MediaStore.Images.Media.DATA};
                    String sel = MediaStore.Images.Media._ID + "=?";

                    Cursor cursor = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                            column, sel, new String[]{id}, null);

                    int columnIndex = cursor.getColumnIndex(column[0]);

                    if (cursor.moveToFirst()) {
                        img_src = cursor.getString(columnIndex);
                        Log.d(LOG_TAG, img_src);
                    }
                    cursor.close();

                    // Upload
                    file = new File(img_src);
                    //Log.d("file",file);
                }
            }

        }
    }
    public static Bitmap rotateImage(Bitmap source, float angle) {
        Matrix matrix = new Matrix();
        matrix.postRotate(angle);
        return Bitmap.createBitmap(source, 0, 0, source.getWidth(), source.getHeight(),
                matrix, true);
    }

    private void chooseImage(View view) {
        Intent intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);

        startActivityForResult(intent, REQUEST_SELECT_PICTURE);
    }

    // 保存草稿，只能保存一个
    public void saveDraft() {
        SharedPreferences.Editor editor = pref.edit();
        String title = postTitle.getText().toString();
        String msg = postMsg.getText().toString();
        editor.putString("TITLE", title);
        editor.putString("MESSAGE", msg);
        editor.commit();
//        Toast.makeText(getActivity().getApplicationContext(), "草稿保存成功", Toast.LENGTH_SHORT).show();
    }

    // 打开页面时，读入草稿
    public void loadDraft() {
        if (pref.contains("TITLE") || pref.contains("MESSAGE")) {
//            Toast.makeText(getActivity().getApplicationContext(), "草稿加载成功", Toast.LENGTH_SHORT).show();
            if (pref.contains("TITLE")) {
                postTitle.setText(pref.getString("TITLE", ""));
            }
            if (pref.contains("MESSAGE")) {
                postMsg.setText(pref.getString("MESSAGE", ""));
            }
        }
    }

    public void onClick(final View v) {
        switch (v.getId()) {
            case R.id.postButton:
                Log.d(LOG_TAG, "Post");
                clickPost(file);
                break;
            case R.id.postPhotoButton:
                capture();
                break;
            default:
                Log.d(LOG_TAG, "No match");
                break;
        }
    }
    public void capture(){
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        File tempDir = getCacheDir();
        File photoFile = null;
        //임시촬영파일 세팅

        try {
            String timeStamp = new SimpleDateFormat("yyyyMMdd").format(new Date());
            String imageFileName = "Capture_" + timeStamp + "_"; //ex) Capture_20201206_
            File tempfile = File.createTempFile(
                    imageFileName,  /* 파일이름 */
                    ".jpg",         /* 파일형식 */
                    tempDir      /* 경로 */

            ); mCurrentPhotoPath = tempfile.getAbsolutePath();

            photoFile = tempfile;
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (photoFile != null) {
            //Uri 가져오기
            Uri photoURI = FileProvider.getUriForFile(this,
                    getPackageName() + ".fileprovider",
                    photoFile);
            //인텐트에 Uri담기
            takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

            //인텐트 실행
            startActivityForResult(takePictureIntent, REQUEST_TAKE_PHOTO);
        }
    }
    private void clickPost(File file) {
        String title = postTitle.getText().toString();
        String type;
        String msg = postMsg.getText().toString();
        if (title.isEmpty() || msg.isEmpty()) {
            Toast.makeText(getApplicationContext(), "动态标题或内容不能为空", Toast.LENGTH_LONG).show();
        } else {
            if (posttype.equals("txtandimg")) {
                Log.d("here1", posttype);
                if (file == null) {
                    type = "TEXT";
                    file = new File("null");
                } else {
                    type = "IMAGE";
                }
                Log.d("type=", type);

            } else if (posttype.equals("audio")) {
                type = "AUDIO";
            } else if (posttype.equals("video")) {
                type = "VIDEO";
            } else {
                Log.e("typeError", posttype);
                return;
            }

//            String jsonStr = "{\"user_id\":\"" + user_id + "\",\"type\":\"" + type
//                    + "\",\"title\":\"" + title + "\",\"text\":\"" + msg + "\",\"media\":\"" + "null" + "\",\"location\":\"" + "hh" + "\"}";
            String requestUrl = getResources().getString(R.string.backend_url) + "create-status";

            try {
                OkHttpClient client = new OkHttpClient();
                MediaType JSON = MediaType.parse("application/json; charset=utf-8");//数据类型为json格式，
                RequestBody requestBody;
                if (type.equals("TEXT")) {
                    requestBody = new MultipartBody.Builder()
                            .setType(MultipartBody.FORM)
                            .addFormDataPart("user_id", user_id)
                            .addFormDataPart("type", type)
                            .addFormDataPart("title", title)
                            .addFormDataPart("text", msg)
                            .addFormDataPart("location", "TEXT")
                            .build();
                } else {
                    requestBody = new MultipartBody.Builder()
                            .setType(MultipartBody.FORM)
                            .addFormDataPart("user_id", user_id)
                            .addFormDataPart("type", type)
                            .addFormDataPart("title", title)
                            .addFormDataPart("text", msg)
                            .addFormDataPart("media", file.getName(),
                                    RequestBody.create(MediaType.parse("image/*"), file))
                            .addFormDataPart("location", "TEXT")
                            .build();
                }
                Request request = new Request.Builder()
                        .url(requestUrl).post(requestBody)
                        .build();
                client.newCall(request).enqueue(new Callback() {
                    @Override
                    public void onFailure(@NotNull Call call, @NotNull IOException e) {
                    }

                    @Override
                    public void onResponse(@NotNull Call call, @NotNull final Response response) throws IOException {
                        final String responseStr = response.body().string();
                        try {
                            JSONObject jObject = new JSONObject(responseStr);
                            boolean status = jObject.getBoolean("status");
                            if (status) {
                            } else {

                                Log.d("messagr", jObject.getString("message"));
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }


            Toast.makeText(getApplicationContext(), "发布成功", Toast.LENGTH_LONG).show();
            postTitle.getText().clear();
            postMsg.getText().clear();

            SharedPreferences.Editor editor = pref.edit();
            editor.clear();
            editor.commit();

            switchContent(title, msg);
        }
    }

    // 用以在点击“发布”后跳转到动态列表页面，通过switchHome来添加动态
    private void switchContent(String title, String msg) {
        if (activity == null) {
            return;
        } else if (activity instanceof MainActivity) {
            Log.d(LOG_TAG, "Switch");
            MainActivity mainActivity = (MainActivity) activity;
            mainActivity.switchHome(title, msg);
        }
    }
}